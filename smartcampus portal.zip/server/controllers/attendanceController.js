const Attendance = require('../models/attendanceModel');
const User = require('../models/userModel');

// Faculty marks attendance
const markAttendance = async (req, res) => {
  const { studentId, status } = req.body;
  const facultyId = req.user._id;
  const role = req.user.role;

  if (role !== 'faculty') {
    return res.status(403).json({ message: 'Only faculty can mark attendance' });
  }

  try {
    const attendance = new Attendance({
      studentId,
      status,
      markedBy: facultyId,
    });

    await attendance.save();
    res.status(201).json({ message: 'Attendance marked', attendance });
  } catch (error) {
    res.status(500).json({ message: 'Error marking attendance', error });
  }
};

// Students view their own attendance
const getAttendance = async (req, res) => {
  const studentId = req.user._id;
  const role = req.user.role;

  if (role !== 'student') {
    return res.status(403).json({ message: 'Only students can view their attendance' });
  }

  try {
    const records = await Attendance.find({ studentId }).sort({ date: -1 });
    res.json(records);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching attendance', error });
  }
};

module.exports = { markAttendance, getAttendance };
