const express = require('express');
const { markAttendance, getAttendance } = require('../controllers/attendanceController');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

// Faculty marks attendance
router.post('/mark', authMiddleware, markAttendance);

// Students get their own attendance
router.get('/my', authMiddleware, getAttendance);

module.exports = router;
