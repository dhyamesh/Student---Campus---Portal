import React, { useEffect, useState } from 'react';
import API from '../services/api';

const AttendanceStudent = () => {
  const [records, setRecords] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const res = await API.get('/attendance/my');
      setRecords(res.data);
    };
    fetchData();
  }, []);

  return (
    <div>
      <h2>My Attendance</h2>
      <ul>
        {records.map((rec, idx) => (
          <li key={idx}>
            {rec.subject} | {new Date(rec.date).toLocaleDateString()} | {rec.status}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AttendanceStudent;
