import React from 'react';
import { getCurrentUser } from '../utils/auth';

const DashboardStudent = () => {
  const user = getCurrentUser();

  return (
  <div className="min-h-screen flex items-center justify-center bg-gray-100">
    <div className="bg-white shadow-lg rounded-lg p-8 max-w-md w-full text-center">
      <h2 className="text-2xl font-bold text-blue-600 mb-4">🎓 Student Dashboard</h2>
      <p className="text-gray-700">
        Welcome, <span className="font-semibold">{user?.name}</span><br />
        Roll No: <span className="text-sm font-mono">{user?.rollNo}</span>
      </p>
    </div>
  </div>
);

};

export default DashboardStudent;
