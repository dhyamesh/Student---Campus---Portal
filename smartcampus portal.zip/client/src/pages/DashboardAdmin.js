import React from 'react';
import { getCurrentUser } from '../utils/auth';

const DashboardAdmin = () => {
  const user = getCurrentUser();

  return (
    <div>
      <h2>Admin Dashboard</h2>
      <p>Welcome, {user?.name}</p>
      {/* Add manage users, fees, announcements later */}
    </div>
  );
};

export default DashboardAdmin;
