import React, { useState } from 'react';
import API from '../services/api';

const AttendanceFaculty = () => {
  const [studentIds, setStudentIds] = useState('');
  const [subject, setSubject] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const ids = studentIds.split(',').map(id => id.trim());
    try {
      await API.post('/attendance/mark', { studentIds: ids, subject });
      alert('Attendance marked');
    } catch (err) {
      alert(err.response?.data?.message || 'Error marking attendance');
    }
  };

  return (
    <div>
      <h2>Mark Attendance</h2>
      <form onSubmit={handleSubmit}>
        <input
          placeholder="Subject"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
        />
        <textarea
          placeholder="Enter student IDs (comma separated)"
          value={studentIds}
          onChange={(e) => setStudentIds(e.target.value)}
        />
        <button type="submit">Mark</button>
      </form>
    </div>
  );
};

export default AttendanceFaculty;
