import React, { useState } from 'react';
import API from '../services/api';

const Register = () => {
  const [form, setForm] = useState({
    name: '', email: '', password: '', role: '', department: '', rollNo: ''
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await API.post('/auth/register', form);
      alert('Registered! Now login.');
    } catch (err) {
      alert(err.response?.data?.message || 'Registration failed');
    }
  };

  return (
    <div>
      <h2>Register</h2>
      <form onSubmit={handleSubmit}>
        <input name="name" onChange={handleChange} placeholder="Name" required />
        <input name="email" onChange={handleChange} placeholder="Email" required />
        <input name="password" type="password" onChange={handleChange} placeholder="Password" required />
        <select name="role" onChange={handleChange} required>
          <option value="">Select Role</option>
          <option value="student">Student</option>
          <option value="faculty">Faculty</option>
          <option value="admin">Admin</option>
        </select>
        <input name="department" onChange={handleChange} placeholder="Department" required />
        {form.role === 'student' && (
          <input name="rollNo" onChange={handleChange} placeholder="Roll No" required />
        )}
        <button type="submit">Register</button>
      </form>
    </div>
  );
};

export default Register;
