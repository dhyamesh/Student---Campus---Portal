import React from 'react';
import { getCurrentUser } from '../utils/auth';

const DashboardFaculty = () => {
  const user = getCurrentUser();

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white shadow-lg rounded-lg p-8 max-w-md w-full text-center">
        <h1 className="text-2xl font-bold text-green-600 mb-4">👨‍🏫 Faculty Dashboard</h1>
        <p className="text-gray-700">
          Welcome, <span className="font-semibold">{user?.name}</span><br />
          Department: <span className="text-sm font-mono">{user?.department}</span>
        </p>
      </div>
    </div>
  );
};

export default DashboardFaculty;
